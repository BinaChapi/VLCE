# Village of Light — Vite website + content API + admin CMS

The existing public website design and `src/content.ts` remain the static fallback. The API stores the site's existing top-level content sections as PostgreSQL JSONB, preserving nested fields and English/Amharic values without flattening or losing array order. The admin dashboard at `/admin` uses a left-hand navigation for Home, About, Programs, Impact & statistics, Contact, Donate, Brand, SEO, Navigation and other content sections.

## Stack

- Existing Vite + React + TypeScript public site
- Express + TypeScript REST API (`server/`)
- Neon PostgreSQL + Prisma (`ContentSection` stores a complete nested section as JSONB)
- Cloudinary image uploads (secure URL returned by Cloudinary and saved into the section when you save)
- Admin login protected by a signed JWT; no public write endpoints

## 1. Configure the API

```bash
cd server
cp .env.example .env
```

Edit `server/.env` with your Neon connection string and credentials. For Neon, use the connection string supplied by Neon and include `sslmode=require`. A pooled connection URL is usually appropriate for serverless deployment; use the direct connection string for migrations if your Neon setup provides one.

Set the following server-only environment variables:

- `DATABASE_URL`: Neon PostgreSQL connection string
- `JWT_SECRET`: a unique random secret at least 32 characters long
- `ADMIN_EMAIL`: admin sign-in email
- `ADMIN_PASSWORD_HASH`: bcrypt hash of your password, never the plain password
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`
- `CORS_ORIGINS`: comma-separated exact frontend origins

Generate a bcrypt hash after installing dependencies:

```bash
cd server
node -e "require('bcryptjs').hash('Use-A-Strong-Password-Here', 12).then(console.log)"
```

Copy the resulting hash into `ADMIN_PASSWORD_HASH`. Replace the sample `JWT_SECRET` with a strong random secret. Never put database, JWT, or Cloudinary API secrets in a `VITE_` variable; those are exposed to the browser.

## 2. Install, create the database table, and import the content

From the repository root:

```bash
npm install
npm install --prefix server
npm run db:generate
npm run db:push
npm run db:seed
```

`db:seed` imports the current `src/content.ts` into the database. It is deliberately idempotent: if a section already exists, it will **not** overwrite your saved CMS changes. To re-import original starter content, back up the database and explicitly edit/delete the relevant database section before seeding again.

## 3. Start frontend and API

Run both in separate terminals:

```bash
# Terminal 1, repository root
npm run dev

# Terminal 2, repository root
npm run dev:api
```

Or use `npm run dev:full` to run both together. Vite proxies `/api` requests to `http://localhost:3001` by default. Set `VITE_API_PROXY_TARGET` if your local API runs elsewhere.

Open:

- Public website: `http://localhost:5173`
- Admin CMS: `http://localhost:5173/admin`
- API health: `http://localhost:3001/api/v1/health`

The public website requests `/api/v1/content` and falls back to bundled `src/content.ts` if the API/database is unavailable. Existing routes and EN/AM language switching remain in place.

## 4. Image workflow

In the admin editor, find a field marked `IMAGE URL`, choose an image, and wait for the upload to finish. The API validates the file type and size, sends it to Cloudinary in the `vlce/content` folder, and returns Cloudinary's `secure_url`. The URL is placed in the field and is persisted to Neon when you click **Save changes** or **Save section**. Configure Cloudinary credentials on the server first. Allowed formats: JPG, PNG, WEBP, GIF and AVIF; default max upload is 10 MB (`MAX_UPLOAD_MB`).

## API routes

Public:

- `GET /api/v1/health`
- `GET /api/v1/content` — all published sections with bilingual nested values
- `GET /api/v1/content/:key` — one published section

Admin (requires `Authorization: Bearer <token>`):

- `POST /api/v1/auth/login`
- `GET /api/v1/admin/sections`
- `GET /api/v1/admin/sections/:key`
- `PUT /api/v1/admin/sections/:key` — save a complete nested section
- `PATCH /api/v1/admin/sections/:key/published`
- `POST /api/v1/admin/images` — multipart form field named `image`

## Build

```bash
npm run build
npm run build:api
```

Before deploying, set all environment variables in your hosting provider, run Prisma generate/push as appropriate, seed the initial content, and configure CORS to your production frontend domain. Deploy the Express API as a separate Node service and point the Vite app's `VITE_API_BASE_URL` at the API base URL (for example `https://api.example.org/api/v1`). If the frontend and API are deployed on separate domains, add the exact frontend origin to `CORS_ORIGINS`.
