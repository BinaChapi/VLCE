import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import { adminApi, getAdminToken, setAdminToken, type AdminSection } from '../api/admin'
import { ContentEditor } from './ContentEditor'
import './admin.css'

const preferredSections = [
  ['home', 'Home', 'House'], ['about', 'About', 'Info'], ['programs', 'Programs', 'Layers'], ['impact', 'Impact & statistics', 'Chart'],
  ['contact', 'Contact', 'Mail'], ['donate', 'Donate & bank details', 'Heart'], ['brand', 'Brand & organization', 'Globe'], ['meta', 'SEO metadata', 'Search'], ['nav', 'Navigation', 'Menu'], ['common', 'Shared labels', 'Settings'],
]
const titleFor = (key: string) => preferredSections.find((x) => x[0] === key)?.[1] || key.replace(/[-_]/g, ' ').replace(/^./, (s) => s.toUpperCase())

function Login({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState('')
  async function submit(e: FormEvent) { e.preventDefault(); setBusy(true); setError(''); try { const result = await adminApi.login(email, password); setAdminToken(result.token); onLogin() } catch (err) { setError(err instanceof Error ? err.message : 'Unable to sign in') } finally { setBusy(false) } }
  return <div className="admin-login-wrap"><form className="admin-login" onSubmit={submit}><div className="admin-mark">VL</div><p className="eyebrow">VILLAGE OF LIGHT</p><h1>Admin sign in</h1><p className="login-copy">Manage website content in English and Amharic.</p>{error && <div className="notice error-notice">{error}</div>}<label className="field"><span>Email address</span><input type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)}/></label><label className="field"><span>Password</span><input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)}/></label><button className="primary-button full-width" disabled={busy}>{busy ? 'Signing in…' : 'Sign in securely'}</button><small className="muted login-foot">Admin credentials are configured on the API server.</small></form></div>
}

export default function Admin() {
  const [authenticated, setAuthenticated] = useState(Boolean(getAdminToken()))
  const [sections, setSections] = useState<AdminSection[]>([]); const [activeKey, setActiveKey] = useState('home'); const [draft, setDraft] = useState<unknown>(null)
  const [loading, setLoading] = useState(false); const [saving, setSaving] = useState(false); const [notice, setNotice] = useState<{ kind: 'success' | 'error'; message: string } | null>(null); const [search, setSearch] = useState(''); const [dirty, setDirty] = useState(false)

  const loadSections = useCallback(async () => {
    setLoading(true); setNotice(null)
    try {
      const rows = await adminApi.listSections(); setSections(rows)
      const first = rows.find((row) => row.key === activeKey) || rows.find((row) => row.key === 'home') || rows[0]
      if (first) { const detail = await adminApi.getSection(first.key); setActiveKey(first.key); setDraft(detail.data); setDirty(false) }
    } catch (error) { setNotice({ kind: 'error', message: error instanceof Error ? error.message : 'Could not load content' }); if (String(error).includes('Session expired') || String(error).includes('Authentication')) { setAdminToken(null); setAuthenticated(false) } }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { if (authenticated) void loadSections() }, [authenticated, loadSections])
  const chooseSection = async (key: string) => {
    if (dirty && !window.confirm('You have unsaved changes. Discard them and switch sections?')) return
    setActiveKey(key); setDraft(null); setNotice(null); setLoading(true)
    try { const result = await adminApi.getSection(key); setDraft(result.data); setDirty(false) }
    catch (error) { setNotice({ kind: 'error', message: error instanceof Error ? error.message : 'Could not load section' }) }
    finally { setLoading(false) }
  }
  const save = async () => {
    setSaving(true); setNotice(null)
    try { const result = await adminApi.saveSection(activeKey, draft); setDraft(result.data); setDirty(false); setNotice({ kind: 'success', message: `${titleFor(activeKey)} saved successfully.` }); setSections((old) => old.map((s) => s.key === activeKey ? { ...s, updatedAt: result.updatedAt } : s)) }
    catch (error) { setNotice({ kind: 'error', message: error instanceof Error ? error.message : 'Could not save section' }) }
    finally { setSaving(false) }
  }
  const orderedSections = useMemo(() => {
    const preferred = preferredSections.map(([key]) => sections.find((s) => s.key === key)).filter((s): s is AdminSection => Boolean(s))
    const other = sections.filter((s) => !preferredSections.some(([key]) => key === s.key)).sort((a, b) => a.key.localeCompare(b.key))
    return [...preferred, ...other].filter((s) => s.key.toLowerCase().includes(search.toLowerCase()) || titleFor(s.key).toLowerCase().includes(search.toLowerCase()))
  }, [sections, search])

  if (!authenticated) return <Login onLogin={() => setAuthenticated(true)}/> 
  return <div className="admin-shell">
    <aside className="admin-sidebar"><div className="sidebar-brand"><div className="admin-mark small-mark">VL</div><div><strong>Village of Light</strong><small>Content management</small></div></div><div className="sidebar-section-label">WEBSITE CONTENT</div><div className="sidebar-search"><input aria-label="Search sections" placeholder="Search sections…" value={search} onChange={(e) => setSearch(e.target.value)}/></div><nav className="admin-nav">{orderedSections.map((section) => <button key={section.key} className={activeKey === section.key ? 'active' : ''} onClick={() => void chooseSection(section.key)}><span className="nav-icon">{section.key === 'home' ? '⌂' : section.key === 'about' ? '◉' : section.key === 'programs' ? '▦' : section.key === 'impact' ? '↗' : section.key === 'contact' ? '✉' : section.key === 'donate' ? '♡' : '◇'}</span><span>{titleFor(section.key)}</span><span className="nav-chevron">›</span></button>)}</nav><div className="sidebar-bottom"><div className="admin-status"><span className="status-dot"/> API-connected admin</div><button className="logout-button" onClick={() => { setAdminToken(null); setAuthenticated(false) }}>↪ Sign out</button></div></aside>
    <main className="admin-main"><header className="admin-topbar"><div><p className="eyebrow">CONTENT MANAGEMENT</p><h1>{titleFor(activeKey)}</h1><p className="topbar-subtitle">Edit published website content in both English and Amharic.</p></div><div className="topbar-actions"><a href="/" target="_blank" rel="noreferrer" className="secondary-button link-button">View website ↗</a><button className="primary-button" disabled={!dirty || saving || loading} onClick={() => void save()}>{saving ? 'Saving…' : 'Save changes'}</button></div></header>
      {notice && <div className={`notice ${notice.kind === 'error' ? 'error-notice' : 'success-notice'}`}><span>{notice.kind === 'error' ? '!' : '✓'}</span>{notice.message}<button onClick={() => setNotice(null)}>×</button></div>}
      <div className="content-toolbar"><div><span className="content-kicker">SECTION EDITOR</span><h2>{titleFor(activeKey)}</h2><p>Update text, links, numbers, lists and images. Changes appear on the public website after saving.</p></div><span className={`save-state ${dirty ? 'unsaved' : ''}`}><span/> {dirty ? 'Unsaved changes' : 'All changes saved'}</span></div>
      {loading || draft === null ? <div className="editor-loading"><span className="spinner"/>Loading section…</div> : <div className="editor-card"><div className="editor-card-header"><div><strong>{activeKey}.content</strong><p>Nested fields are grouped by object; EN / AM fields are shown together.</p></div><span className="field-count">{draft && typeof draft === 'object' ? Object.keys(draft as object).length : 0} top-level fields</span></div><div className="editor-card-body"><ContentEditor value={draft} path={activeKey} onChange={(next) => { setDraft(next); setDirty(true) }}/></div><div className="editor-card-footer"><span className="muted">Remember to save your edits before leaving this section.</span><button className="primary-button" disabled={!dirty || saving} onClick={() => void save()}>{saving ? 'Saving…' : 'Save section'}</button></div></div>}
      <footer className="admin-footer">VLCE Admin <span>•</span> Content is stored in Neon PostgreSQL <span>•</span> Images are hosted by Cloudinary</footer>
    </main>
  </div>
}
