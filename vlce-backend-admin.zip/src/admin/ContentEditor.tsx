import { useRef, useState } from 'react'
import { adminApi } from '../api/admin'

type Props = { value: unknown; path: string; onChange: (next: unknown) => void; depth?: number }
const humanize = (key: string) => key.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[-_]/g, ' ').replace(/^./, (s) => s.toUpperCase())
const isImageField = (key: string, value: unknown) => typeof value === 'string' && (/image|photo|picture|logo|icon|banner|cover|avatar|src/i.test(key) || value.startsWith('/images/') || value.includes('res.cloudinary.com'))

export function ContentEditor({ value, path, onChange, depth = 0 }: Props) {
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)
  const key = path.split('.').at(-1) || path

  if (Array.isArray(value)) {
    return <section className={`editor-group depth-${Math.min(depth, 3)}`}>
      <div className="editor-group-heading"><span>{humanize(key)}</span><span className="muted">{value.length} items</span><button type="button" className="small-button" onClick={() => onChange([...value, value.length && typeof value[0] === 'object' ? structuredClone(value[0]) : ''])}>+ Add item</button></div>
      {value.map((item, index) => <div className="array-item" key={`${path}-${index}`}><div className="array-item-heading"><strong>{humanize(key)} {index + 1}</strong><button type="button" className="text-danger" onClick={() => onChange(value.filter((_, i) => i !== index))}>Remove</button></div><ContentEditor value={item} path={`${path}.${index}`} depth={depth + 1} onChange={(next) => onChange(value.map((old, i) => i === index ? next : old))}/></div>)}
    </section>
  }

  if (value && typeof value === 'object') {
    const entries = Object.entries(value as Record<string, unknown>)
    const localized = entries.length === 2 && entries.every(([k, v]) => ['en', 'am'].includes(k) && typeof v === 'string')
    return <section className={`editor-group depth-${Math.min(depth, 3)} ${localized ? 'localized-group' : ''}`}>
      {!localized && <div className="editor-group-heading"><span>{humanize(key)}</span>{depth > 0 && <span className="muted">{entries.length} fields</span>}</div>}
      {localized ? <div className="bilingual-fields">{(['en', 'am'] as const).map((lang) => <label className="field" key={lang}><span>{lang === 'en' ? 'English' : 'አማርኛ'} <small>{lang.toUpperCase()}</small></span><textarea rows={String((value as Record<string, unknown>)[lang]).length > 100 ? 4 : 2} value={String((value as Record<string, unknown>)[lang] ?? '')} onChange={(e) => onChange({ ...(value as object), [lang]: e.target.value })}/></label>)}</div> : entries.map(([childKey, child]) => <ContentEditor key={`${path}.${childKey}`} value={child} path={`${path}.${childKey}`} depth={depth + 1} onChange={(next) => onChange({ ...(value as Record<string, unknown>), [childKey]: next })}/>)}
    </section>
  }

  if (typeof value === 'boolean') return <label className="boolean-field"><span>{humanize(key)}</span><input type="checkbox" checked={value} onChange={(e) => onChange(e.target.checked)}/></label>
  if (typeof value === 'number') return <label className="field"><span>{humanize(key)}</span><input type="number" value={value} onChange={(e) => onChange(e.target.value === '' ? 0 : Number(e.target.value))}/></label>
  const text = value == null ? '' : String(value)
  const imageField = isImageField(key, value)
  const longText = text.length > 120 || /description|paragraph|mission|vision|story|quote|content|text/i.test(key)
  const handleUpload = async (file?: File) => {
    if (!file) return
    setUploading(true); setUploadError('')
    try { const uploaded = await adminApi.uploadImage(file); onChange(uploaded.url) }
    catch (error) { setUploadError(error instanceof Error ? error.message : 'Upload failed') }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = '' }
  }
  return <label className="field">
    <span>{humanize(key)}{imageField && <small>IMAGE URL</small>}</span>
    {longText && !imageField ? <textarea rows={4} value={text} onChange={(e) => onChange(e.target.value)}/> : <input type="text" value={text} onChange={(e) => onChange(e.target.value)} />}
    {imageField && <div className="image-tools"><div className="image-preview">{text ? <img src={text} alt="Selected content" onError={(e) => { e.currentTarget.style.display = 'none' }} /> : <span>No image selected</span>}</div><div className="image-actions"><button type="button" className="secondary-button" disabled={uploading} onClick={() => fileRef.current?.click()}>{uploading ? 'Uploading…' : 'Choose & upload image'}</button><input ref={fileRef} hidden type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/avif" onChange={(e) => void handleUpload(e.target.files?.[0])}/><small>Image is uploaded to Cloudinary; its secure URL is saved with this section.</small>{uploadError && <span className="error-text">{uploadError}</span>}</div></div>}
  </label>
}
