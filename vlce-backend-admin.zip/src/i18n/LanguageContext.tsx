import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { content, type Lang } from '../content'

function localize(value: unknown, lang: Lang): unknown {
  if (Array.isArray(value)) return value.map((item) => localize(item, lang))

  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>

    if ('en' in record && 'am' in record && Object.keys(record).length === 2) {
      return record[lang]
    }

    return Object.fromEntries(
      Object.entries(record).map(([key, child]) => [key, localize(child, lang)]),
    )
  }

  return value
}

type Localized<T> = T extends readonly (infer U)[]
  ? Localized<U>[]
  : T extends { en: infer E; am: infer _A }
    ? Localized<E>
    : T extends object
      ? { [K in keyof T]: Localized<T[K]> }
      : T

export type Dictionary = Localized<typeof content>

function getDictionary(lang: Lang): Dictionary {
  return localize(content, lang) as Dictionary
}

interface LanguageValue {
  lang: Lang
  setLang: (l: Lang) => void
  t: Dictionary
}

const LanguageContext = createContext<LanguageValue>({
  lang: 'en',
  setLang: () => {},
  t: getDictionary('en'),
})

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [sourceContent, setSourceContent] = useState<typeof content>(content)
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem('vlce-lang')
    return saved === 'am' || saved === 'en' ? saved : 'en'
  })

  useEffect(() => {
    const base = (import.meta.env.VITE_API_BASE_URL || '/api/v1').replace(/\/$/, '')
    const controller = new AbortController()
    fetch(`${base}/content`, { signal: controller.signal })
      .then((response) => { if (!response.ok) throw new Error('Content API unavailable'); return response.json() })
      .then((payload: { success?: boolean; data?: unknown }) => {
        if (payload.success && payload.data && typeof payload.data === 'object' && Object.keys(payload.data).length > 0) setSourceContent(payload.data as typeof content)
      })
      .catch(() => { /* Keep the bundled content as a safe offline/static fallback. */ })
    return () => controller.abort()
  }, [])

  useEffect(() => {
    localStorage.setItem('vlce-lang', lang)
    document.documentElement.lang = lang === 'am' ? 'am' : 'en'
  }, [lang])

  const setLang = (l: Lang) => setLangState(l)
  const t = localize(sourceContent, lang) as Dictionary

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => useContext(LanguageContext)
